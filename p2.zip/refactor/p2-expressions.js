/*
    CIT 281 Project 2
    Name: Sofi Spliethof
*/

// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
  }
  
 // Returns a single random lowercase letter
function getRandomLetter() {
    const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
    const letterbank = getRandomInteger(1,alphabet.length - 1);
    return alphabet[letterbank];
  }

// Returns a random length string
function getRandomString(minLength,maxLength) {
    const length = getRandomInteger(minLength, maxLength)
    let result = "";
    for (let i = 0; i < length; i++) {
        result += getRandomLetter();
    }
    return result;
}


console.log(getRandomString(10,20));